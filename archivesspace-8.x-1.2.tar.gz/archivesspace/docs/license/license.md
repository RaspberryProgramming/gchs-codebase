AS2D8 is licensed on the same terms as Drupal, under GPLv2 or later.

[About Drupal licensing](https://www.drupal.org/about/licensing)

The AS2d8 license also covers its related modules, hacks, plugins, and configuration management.